using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeEventTest : MonoBehaviour
{
    void TestEventCallback()
    {
        Debug.Log("Event Received!");
    }
}
